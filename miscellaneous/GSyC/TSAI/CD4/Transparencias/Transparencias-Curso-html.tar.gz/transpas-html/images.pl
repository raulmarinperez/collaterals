# LaTeX2HTML 99.2beta6 (1.42)
# Associate images original text with physical files.


$key = q/includegraphics[height=5cm]{figsslashsecurity-ipsec-esp-place-trp};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="78" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\includegraphics[height=5cm]{figs/security-ipsec-esp-place-trp}">|; 

$key = q/includegraphics[height=5cm]{figsslashsecurity-ipsec-ah-place-trp};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="78" HEIGHT="64" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="\includegraphics[height=5cm]{figs/security-ipsec-ah-place-trp}">|; 

$key = q/includegraphics[height=5cm]{figsslashsecurity-ipsec-esp-place-tun};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="116" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\includegraphics[height=5cm]{figs/security-ipsec-esp-place-tun}">|; 

$key = q/includegraphics[width=12.5cm]{figsslashrtphdr};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="113" HEIGHT="198" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\includegraphics[width=12.5cm]{figs/rtphdr}">|; 

$key = q/includegraphics[height=5cm]{figsslashsecurity-ipsec-ah-place-tun};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="77" HEIGHT="105" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="\includegraphics[height=5cm]{figs/security-ipsec-ah-place-tun}">|; 

$key = q/includegraphics[height=6.5cm]{figsslashrtsp};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="111" HEIGHT="143" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="\includegraphics[height=6.5cm]{figs/rtsp}">|; 

$key = q/includegraphics[height=5cm]{figsslashsecurity-ipsec-esp};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="78" HEIGHT="81" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\includegraphics[height=5cm]{figs/security-ipsec-esp}">|; 

$key = q/includegraphics[height=5cm]{figsslashsecurity-ipsec-ah};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="79" HEIGHT="81" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\includegraphics[height=5cm]{figs/security-ipsec-ah}">|; 

$key = q/includegraphics[height=6cm]{figsslashcontrol-accesos};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="136" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics[height=6cm]{figs/control-accesos}">|; 

1;

