# LaTeX2HTML 99.2beta6 (1.42)
# Associate images original text with physical files.


$key = q/includegraphics[height=0.7cm]{gsyc2};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="31" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[height=0.7cm]{gsyc2}">|; 

1;

